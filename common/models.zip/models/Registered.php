<?php

namespace common\models;

use Yii;
use yii\helpers\HtmlPurifier;
use yii\helpers\Url;

/**
 * This is the model class for table "registered".
 *
 * @property int $id
 * @property string $name
 * @property string $lastname
 * @property string $fname
 * @property string $pser
 * @property string $pnum
 * @property int|null $region_id
 * @property int|null $type
 * @property int|null $lang_id
 * @property int $status
 * @property int $created_at
 * @property int $updated_at
 */
class Registered extends \yii\db\ActiveRecord
{
    public $codecap;
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'registered';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['name', 'lastname', 'fname', 'pser', 'pnum'], 'required'],
            [['region_id', 'type', 'lang_id', 'status'], 'integer'],
            [['name'], 'string', 'max' => 32],
            [['lastname', 'fname', 'pser', 'pnum', 'phone','workplace'], 'string', 'max' => 255],
            [['pser', 'pnum'], 'unique', 'targetAttribute' => ['pser', 'pnum']],
            [['created_at', 'updated_at'], 'default', 'value' => time()],
            [['codecap'], 'captcha', 'captchaAction' => '/registered/captcha']
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            // 'id' => 'ID',
            'name' => 'Ismingiz',
            'lastname' => 'Familyangiz',
            'fname' => 'Otangizning ismi',
            'pser' => 'Pasport seriyasi yoki (Guvohnoma seriyasi)',
            'pnum' => 'Pasport seriyasi raqami yoki (Guvohnoma raqami)',
            'phone' => 'Telefon raqami ',
            'region_id' => 'Tug\'ulgan joyingiz',
            'type' => 'Kurs turi',
            'lang_id' => 'Ta\'lim tilini tanlang',
            'status' => 'Status',
            'codecap' => 'Tekshiruv kodi',
            'workplace' => 'Ish joyi',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }
    public function beforeSave($insert)
    {
        if (parent::beforeSave($insert)) {
            $this->name = self::purifier($this->name);
            $this->lastname = self::purifier($this->lastname);
            $this->fname = self::purifier($this->fname);
            $this->pser = self::purifier($this->pser);
            $this->pnum = self::purifier($this->pnum);
            return true;
        } else {
            return false;
        }
    }

    public static function purifier($text)
    {
        $pr = new HtmlPurifier;
        return $pr->process($text);
    }
    public function getRegion()
    {
        return $this->hasOne(Region::className(), ['id' => 'region_id']);
    }
    public function getCours()
    {
        return $this->hasOne(CoursBlock::className(), ['id' => 'type']);
    }
    public function getLang()
    {
        return $this->hasOne(Language::className(), ['id' => 'lang_id']);
    }
}
